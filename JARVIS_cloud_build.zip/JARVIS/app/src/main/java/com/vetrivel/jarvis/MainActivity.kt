package com.vetrivel.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.vetrivel.jarvis.ui.theme.JARVISTheme
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false

    private var status by mutableStateOf("SYSTEMS READY")
    private var recognizedText by mutableStateOf("Tap VOICE to speak.")
    private var voiceResponse by mutableStateOf("Awaiting your command.")

    private val microphonePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startListening()
            } else {
                status = "MICROPHONE PERMISSION DENIED"
                voiceResponse = "Microphone permission is required for voice input."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        textToSpeech = TextToSpeech(this, this)

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    status = "LISTENING"
                    voiceResponse = "Listening, sir."
                }

                override fun onBeginningOfSpeech() {
                    status = "HEARING VOICE"
                }

                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    status = "PROCESSING"
                }

                override fun onError(error: Int) {
                    status = "VOICE INPUT STOPPED"
                    voiceResponse = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "I could not understand that. Please try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Tap VOICE to retry."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                        else -> "Speech recognition failed. Please try again."
                    }
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenWords = matches?.firstOrNull().orEmpty()

                    if (spokenWords.isNotBlank()) {
                        recognizedText = spokenWords
                        status = "VOICE RECEIVED"
                        voiceResponse = "I heard you say: $spokenWords"
                        speak(voiceResponse)
                    } else {
                        status = "NO SPEECH DETECTED"
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        } else {
            status = "SPEECH RECOGNITION UNAVAILABLE"
        }

        setContent {
            JARVISTheme {
                JARVISHome(
                    status = status,
                    recognizedText = recognizedText,
                    voiceResponse = voiceResponse,
                    onVoiceClick = { requestVoiceInput() },
                    onCameraClick = {
                        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                        if (intent.resolveActivity(packageManager) != null) {
                            startActivity(intent)
                        } else {
                            status = "CAMERA APP UNAVAILABLE"
                        }
                    },
                    onStatusClick = {
                        voiceResponse = "JARVIS application is running. Voice recognition availability: ${
                            if (SpeechRecognizer.isRecognitionAvailable(this)) "available" else "unavailable"
                        }."
                        status = "SYSTEM STATUS CHECKED"
                        speak(voiceResponse)
                    }
                )
            }
        }
    }

    override fun onInit(result: Int) {
        ttsReady = result == TextToSpeech.SUCCESS
        if (ttsReady) {
            textToSpeech?.language = Locale.getDefault()
        }
    }

    private fun requestVoiceInput() {
        if (speechRecognizer == null) {
            status = "SPEECH RECOGNITION UNAVAILABLE"
            voiceResponse = "This device does not currently provide a speech recognition service."
            speak(voiceResponse)
            return
        }

        val permission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        )

        if (permission == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            microphonePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }

        try {
            status = "STARTING VOICE"
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            status = "COULD NOT START VOICE"
            voiceResponse = "Unable to start speech recognition."
        }
    }

    private fun speak(message: String) {
        if (ttsReady) {
            textToSpeech?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_RESPONSE")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        super.onDestroy()
    }
}

@Composable
fun JARVISHome(
    status: String,
    recognizedText: String,
    voiceResponse: String,
    onVoiceClick: () -> Unit,
    onCameraClick: () -> Unit,
    onStatusClick: () -> Unit
) {
    val background = Color(0xFF05070A)
    val panel = Color(0xFF0D1117)
    val accent = Color(0xFF00BFFF)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(background)
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "JARVIS",
                color = accent,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "PERSONAL AI SYSTEM",
                color = Color.Gray,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(30.dp))

            Box(
                modifier = Modifier
                    .size(170.dp)
                    .clip(CircleShape)
                    .background(panel),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "J",
                        color = accent,
                        fontSize = 72.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = status,
                        color = if (status == "LISTENING") accent else Color.Green,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(25.dp))

            Text("Good day, sir.", color = Color.White, fontSize = 20.sp)

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = recognizedText,
                color = accent,
                fontSize = 15.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = voiceResponse,
                color = Color.Gray,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(25.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onVoiceClick,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = panel),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("VOICE", color = accent)
                }

                Button(
                    onClick = onCameraClick,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = panel),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("CAMERA", color = accent)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onStatusClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = panel),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("SYSTEM STATUS", color = accent)
            }
        }
    }
}
